#include <osgViewer/InputParameter>

using namespace osgViewer;

